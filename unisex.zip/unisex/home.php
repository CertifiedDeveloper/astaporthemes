<?php
/**
 * The home template file.
 *
 * @package unisex
 */

get_header(); ?>

	<?php do_action('unisex_before_content'); ?>

	<div id="primary" class="content-area col-md-9 <?php echo unisex_blog_layout(); ?>">
		<main id="main" class="post-wrap" role="main">

		<?php if ( have_posts() ) : ?>

		<div class="posts-layout">
			<?php while ( have_posts() ) : the_post(); ?>

				<?php
					get_template_part( 'content', get_post_format() );
				?>

			<?php endwhile; ?>
		</div>

			<?php the_posts_navigation(); ?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
<div class="col-md-3">
    <?php
    get_sidebar();
    ?>
</div>

	<?php do_action('unisex_after_content'); ?>


<?php get_footer(); ?>
