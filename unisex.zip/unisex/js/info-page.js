
;(function($) {

	$('.unisex-tab-nav a').on('click',function (e) {
		e.preventDefault();
		$(this).addClass('active').siblings().removeClass('active');
	});

	$('.unisex-tab-nav .begin').on('click',function (e) {
		$('.unisex-tab-wrapper .begin').addClass('show').siblings().removeClass('show');
	});	
	$('.unisex-tab-nav .actions, .unisex-tab .actions').on('click',function (e) {
		e.preventDefault();
		$('.unisex-tab-wrapper .actions').addClass('show').siblings().removeClass('show');

		$('.unisex-tab-nav a.actions').addClass('active').siblings().removeClass('active');

	});	
	$('.unisex-tab-nav .support').on('click',function (e) {
		$('.unisex-tab-wrapper .support').addClass('show').siblings().removeClass('show');
	});	
	$('.unisex-tab-nav .table').on('click',function (e) {
		$('.unisex-tab-wrapper .table').addClass('show').siblings().removeClass('show');
	});	


	$('.unisex-tab-wrapper .install-now').on('click',function (e) {
		$(this).replaceWith('<p style="color:#23d423;font-style:italic;font-size:14px;">Plugin installed and active!</p>');
	});	
	$('.unisex-tab-wrapper .install-now.importer-install').on('click',function (e) {
		$('.importer-button').show();
	});	


})(jQuery);
