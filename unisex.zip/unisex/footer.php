<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package unisex
 */
?>
			</div>
		</div>
	</div><!-- #content -->

	<?php do_action('unisex_before_footer'); ?>

	<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
		<?php get_sidebar('footer'); ?>
	<?php endif; ?>

    <a class="go-top"><i class="fa fa-angle-up"></i></a>
		
	<footer id="colophon" class="site-footer" role="contentinfo">
        <div class="container">
        <div class="row">
		<div class="col-sm-4 site-info container">
            Copyright © All Rights Reserved by <a style="color: #d00009">Unisex Salon</a>
		</div><!-- .site-info -->
        <div class="col-sm-8 footer-menu">
            <?php if ( is_active_sidebar( 'footer-menu' ) ) { ?>
              <?php dynamic_sidebar( 'footer-menu' ); ?>
          <?php } ?>
        </div>
        </div></div>
	</footer><!-- #colophon -->

	<?php do_action('unisex_after_footer'); ?>

</div><!-- #page -->

<?php wp_footer(); ?>
<script type="text/javascript">
  jQuery(document).ready(function () {

  })
</script>
</body>
</html>
